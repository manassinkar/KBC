package Questions;
public class OneThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="RASH/Prickly heat (Ghamoriyan) is associated with?";
				q[1]="(A) Hair";
				q[2]="(B) Skin";
				q[3]="(C) Nails";
				q[4]="(D) Eyes";
				q[5]="B";
				break;
			}
			case 2:
			{
				q[0]="Which of these organs are found only in women ?";
				q[1]="(A) Appendix";
				q[2]="(B) Ovaries";
				q[3]="(C) Large Intestine";
				q[4]="(D) Pancreas";
				q[5]="B";
				break;
			}
			case 3:
			{
				q[0]="According to Islamic tradition ,in which month was the holy Quran revealed to the Prophet Mohammad?";
				q[1]="(A) Muharram";
				q[2]="(B) Dhu al – Hijjah";
				q[3]="(C) Ramadan";
				q[4]="(D) Rajab";
				q[5]="C";
				break;
			}
			case 4:
			{
				q[0]="Which of these is a kind of song to make children fall asleep?";
				q[1]="(A) Chori";
				q[2]="(B) Mori";
				q[3]="(C) Lori";
				q[4]="(D) Hori";
				q[5]="C";
				break;
			}
			case 5:
			{
				q[0]="Which planet has the shortest year and the longest day in the solar system?";
				q[1]="(A) Mercury";
				q[2]="(B) Mars";
				q[3]="(C) Jupiter";
				q[4]="(D) Neptune";
				q[5]="A";
				break;
			}
			case 6:
			{
				q[0]="How many queens are there in a game of carrom?";
				q[1]="(A) 2";
				q[2]="(B) 1";
				q[3]="(C) 3";
				q[4]="(D) 4";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="Identify the film from the song (Goonja sa hai koi ektara iktara)";
				q[1]="(A) Rockstar";
				q[2]="(B) Luck by chance";
				q[3]="(C) Ajab Prem Ki Gajab Kahani";
				q[4]="(D) Wake up Sid";
				q[5]="D";
				break;
			}
			case 8:
			{
				q[0]="Identify the singer (Kahin Door Jab Din Dhal Jaye)";
				q[1]="(A) Kishore Kumar";
				q[2]="(B) Mahendra Kapoor";
				q[3]="(C) Mohammad Rafi";
				q[4]="(D) Mukesh";
				q[5]="D";
				break;
			}
			case 9:
			{
				q[0]="Which of these is the chief chemical content in tobacco ?";
				q[1]="(A) Caffeine";
				q[2]="(B) Cocaine";
				q[3]="(C) Cocoa";
				q[4]="(D) Nicotine";
				q[5]="D";
				break;
			}
			case 10:
			{
				q[0]="Starting with the least, arrange these cloth items according to the amount of cloth normally required to make them.(1) Saree (2) Blouse (3) Handkerchief (4) Pyjama";
				q[1]="(A) 3-2-4-1";
				q[2]="(B) 4-2-1-3";
				q[3]="(C) 1-2-4-3";
				q[4]="(D) 3-4-2-1";
				q[5]="A";
				break;
			}
		}
		return q;
	}
}