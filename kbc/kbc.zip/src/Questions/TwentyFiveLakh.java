package Questions;
public class TwentyFiveLakh
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Which of these did Bimbisara, the king of Magadha, get as dowry on marrying the daughter of the king of Kosala?";
				q[1]="(A) Pataliputra";
				q[2]="(B) Kashi";
				q[3]="(C) Anga";
				q[4]="(D) Vaisali";
				q[5]="B";
				break;
			}
			case 2:
			{
				q[0]="After which of these personalities, one time Lieutenant Governor of Punjab, is a suburb in Dharamshala named?";
				q[1]="(A) Lord Dalhousie";
				q[2]="(B) Sir Donald McLeod";
				q[3]="(C) Sir Edward Bames";
				q[4]="(D) Lord Lansdowne";
				q[5]="B";
				break;
			}
			case 3:
			{
				q[0]="Which of these terms is used for a state of political hostility characterized by threats or propaganda between countries?";
				q[1]="(A) Summer War";
				q[2]="(B) Cold War";
				q[3]="(C) Rainy War";
				q[4]="(D) Spring War ";
				q[5]="B";
				break;
			}
			case 4:
			{
				q[0]="Who founded the political party National People’s Party (NPP) in January 2013?";
				q[1]="(A) Amar Singh";
				q[2]="(B) B. S. Yeddyurappa";
				q[3]="(C) P. A. Sangama";
				q[4]="(D) Keshubhai Patel";
				q[5]="C";
				break;
			}
			case 5:
			{
				q[0]="During the start of his political life, Sher Shah Suri was the ‘jagirdar’ of which place?";
				q[1]="(A) Rohtak";
				q[2]="(B) Sasaram";
				q[3]="(C) Mathua";
				q[4]="(D) Darbhaga";
				q[5]="B";
				break;
			}
			case 6:
			{
				q[0]="Who holds the record of being elected to the Lok Sabha for the most number of terms?";
				q[1]="(A) Atal Bihari Vajpayee";
				q[2]="(B) Indrajit Gupta";
				q[3]="(C) P. M. Sayeed";
				q[4]="(D) Babu Jagjivan Ram";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="Kaiser-i-Hind, found mostly in Nepal and the north-eastern part of India, is a rare species of which type of organism?";
				q[1]="(A) Fish";
				q[2]="(B) Butterfly";
				q[3]="(C) Bee";
				q[4]="(D) Lizard";
				q[5]="B";
				break;
			}
			case 8:
			{
				q[0]="Who is the singer of ‘Pi’s Lullby, the Oscar-nominated song from the movie ‘Life of Pi’?";
				q[1]="(A) Mahalakshmi Iyer";
				q[2]="(B) K. S. Chithra";
				q[3]="(C) Bombay Jayashri";
				q[4]="(D) Suchitra";
				q[5]="C";
				break;
			}
			case 9:
			{
				q[0]="The cricket Test series played between India and England in India is contested for which trophy?";
				q[1]="(A) Pataudi Trophy";
				q[2]="(B) Anthony De Mello trophy";
				q[3]="(C) M. A. Chidambaram Trophy";
				q[4]="(D) Gooch Gavaskar Trophy";
				q[5]="B";
				break;
			}
			case 10:
			{
				q[0]="To whom did Ravindranath Tagore dedicate his book ‘visva parichay’ written on science?";
				q[1]="(A) C v Raman";
				q[2]="(B) Jagdish chandra Bose";
				q[3]="(C) P c Roy";
				q[4]="(D) Satyendra nath Bose";
				q[5]="D";
				break;
			}
		}
		return q;
	}
}