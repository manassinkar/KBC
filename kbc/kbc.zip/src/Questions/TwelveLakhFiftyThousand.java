package Questions;
public class TwelveLakhFiftyThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="By what name do we better know the religious personality whose original name was Ghanshyam?";
				q[1]="(A) Bhagwan Swaminarayan";
				q[2]="(B) Sathya Sai Baba";
				q[3]="(C) Dayanand Saraswati";
				q[4]="(D) Ramakrishnan Paramahansa";
				q[5]="A";
				break;
			}
			case 2:
			{
				q[0]="After which musical note is the music director R D. Burman nicknamed ?";
				q[1]="(A) Shadaj";
				q[2]="(B) Madhyam";
				q[3]="(C) Pancham";
				q[4]="(D) Nishad";
				q[5]="C";
				break;
			}
			case 3:
			{
				q[0]="By what name is the Test Cricketer Mudhusudan Singh better known?";
				q[1]="(A) M. S. Dhoni";
				q[2]="(B) Monty Panesar";
				q[3]="(C) M. S. K. Prasad";
				q[4]="(D) Murali Vijay";
				q[5]="B";
				break;
			}
			case 4:
			{
				q[0]="In the Kurukshetra war, Arjuna shot arrows at Bhishma hiding behind which character?";
				q[1]="(A) Dhrishtadyumna";
				q[2]="(B) Shikhandi";
				q[3]="(C) Satyaki";
				q[4]="(D) Virata";
				q[5]="B";
				break;
			}
			case 5:
			{
				q[0]="Which of these did German scientists Fntz Haber and Karl Bosch synthesise through an industrial process in 1909?";
				q[1]="(A) Ammonia";
				q[2]="(B) Methane";
				q[3]="(C) Nitrogen";
				q[4]="(D) Oxygen";
				q[5]="A";
				break;
			}
			case 6:
			{
				q[0]="What title did Mahatma Gandhi give to his 1908 translation of John Ruskin’s work, 'Unto the Last?'";
				q[1]="(A) Satyagraha";
				q[2]="(B) Sarvodaya";
				q[3]="(C) Ahimsa";
				q[4]="(D) Khilafat";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="In which sport has Jwala Gutta been a 13-time National Champion?";
				q[1]="(A) Badminton";
				q[2]="(B) Chess";
				q[3]="(C) Squash";
				q[4]="(D) Table Tennis";
				q[5]="A";
				break;
			}
			case 8:
			{
				q[0]="Which of these Union portfolios have Dinesh Trivedi, Mukul Roy & Pawan kumar Bansal all held at some point in 2012?";
				q[1]="(A) Coal";
				q[2]="(B) Railways";
				q[3]="(C) Chemicals & fertilizers";
				q[4]="(D) Commerce & study";
				q[5]="B";
				break;
			}
			case 9:
			{
				q[0]="What was the name of India’s first test tube baby developed using IVF technique by Dr Subhas Mukherjee?";
				q[1]="(A) Lakshmi";
				q[2]="(B) Saraswati";
				q[3]="(C) Kali";
				q[4]="(D) Durga";
				q[5]="D";
				break;
			}
			case 10:
			{
				q[0]="Who among these is maternal grandson or granddaughter of Dr. Zakir Hussain, the third president of India?";
				q[1]="(A) Salman Khurshid";
				q[2]="(B) Khurshid Alam Khan";
				q[3]="(C) Ghulam Nabi Azad";
				q[4]="(D) Najma Heptulla";
				q[5]="A";
				break;
			}
		}
		return q;
	}
}