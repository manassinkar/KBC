package Questions;
public class FortyThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Which of these is the name for a kind of shot in badminton ?";
				q[1]="(A) Bounce";
				q[2]="(B) Yorker";
				q[3]="(C) Drop";
				q[4]="(D) Bout";
				q[5]="C";
				break;
			}
			case 2:
			{
				q[0]="Which is the least populated state of India?";
				q[1]="(A) Manipur";
				q[2]="(B) Arunachal Pradesh";
				q[3]="(C) Sikkim";
				q[4]="(D) Goa";
				q[5]="C";
				break;
			}
			case 3:
			{
				q[0]="Which actor played the title role of 'Agent Vinod' in the 1977 film of the same name?";
				q[1]="(A) Mahendra Sandhu";
				q[2]="(B) Vinod Mehra";
				q[3]="(C) Vinod Khanna";
				q[4]="(D) Navin Nischol";
				q[5]="A";
				break;
			}
			case 4:
			{
				q[0]="Which of these personalities is known as the ‘Flying Sikh’?";
				q[1]="(A) Gurbachan Singh Randhawa";
				q[2]="(B) Harbhajan Singh";
				q[3]="(C) Navjot Singh Sidhu";
				q[4]="(D) Milkha Singh";
				q[5]="D";
				break;
			}
			case 5:
			{
				q[0]="Which of these brands of pens is named after highest peak in Western Europe?";
				q[1]="(A) Reynolds";
				q[2]="(B) Montblanc";
				q[3]="(C) Faber-Castell";
				q[4]="(D) Sheaffer";
				q[5]="B";
				break;
			}
			case 6:
			{
				q[0]="Arrange these words in the correct order to form the starting line of a popular bhajan ?(1) Mere (2) Girdhar (3) To (4) Gopal";
				q[1]="(A)1-2-4-3";
				q[2]="(B)1-3-2-4";
				q[3]="(C)4-2-3-1";
				q[4]="(D)2-1-3-4";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="Which of these numbers is used before the word 'Shringar' to describe a fully beautiful women ?";
				q[1]="(A) Chhattees";
				q[2]="(B) Solah";
				q[3]="(C) Chhappan";
				q[4]="(D) Gyarah";
				q[5]="B";
				break;
			}
			case 8:
			{
				q[0]="Which of these is a chemical element present in the periodic table?";
				q[1]="(A) Eurocium";
				q[2]="(B) Americium";
				q[3]="(C) Asiacium";
				q[4]="(D) Africium";
				q[5]="B";
				break;
			}
			case 9:
			{
				q[0]="Which of these names means ‘gold-like’?";
				q[1]="(A) Sonakshi";
				q[2]="(B) Sonam";
				q[3]="(C) Sumita";
				q[4]="(D) Sanjana";
				q[5]="B";
				break;
			}
			case 10:
			{
				q[0]="With reference to genetics, which of these would best describe DNA and RNA?";
				q[1]="(A) Base";
				q[2]="(B) Acid";
				q[3]="(C) Salt";
				q[4]="(D) Metal";
				q[5]="B";
				break;
			}
		}
		return q;
	}
}