package Questions;
public class FiveThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Which of these devices convert alternating current or AC into direct current or DC?";
				q[1]="(A) Inverter";
				q[2]="(B) Transformer";
				q[3]="(C) Rectifier";
				q[4]="(D) Transmitter";
				q[5]="C";
				break;
			}
			case 2:
			{
				q[0]="Starting from the earliest , arrange these pairs in chronological order of their first appearance together in Hindi films.(1) Salman Khan – Katrina Kaif (2) Raj Kapoor – Nargis (3) Shah Rukh Khan – Kajol (4) Rajesh Khanna – Mumtaz";
				q[1]="(A)1-2-4-3";
				q[2]="(B)4-2-1-3";
				q[3]="(C)2-4-3-1";
				q[4]="(D)4-2-3-1";
				q[5]="C";
				break;
			}
			case 3:
			{
				q[0]="Which of these flowers have prickles on their stems ?";
				q[1]="(A) Genda";
				q[2]="(B) Kamal";
				q[3]="(C) Gulab";
				q[4]="(D) Rajanigandha";
				q[5]="C";
				break;
			}
			case 4:
			{
				q[0]="In Which of these sports are a 'ball' , 'gloves' and 'helmet' part of playing equipment ?";
				q[1]="(A) Hockey";
				q[2]="(B) Volleyball";
				q[3]="(C) Tennis";
				q[4]="(D) Badminton";
				q[5]="A";
				break;
			}
			case 5:
			{
				q[0]="Which of these metals or non-metals is the main constituent of both brass and bronze ?";
				q[1]="(A) Carbon";
				q[2]="(B) Lead";
				q[3]="(C) Copper";
				q[4]="(D) Silver";
				q[5]="C";
				break;
			}
			case 6:
			{
				q[0]="As a captain, which cricketer holds the record for winning the most number of tests?";
				q[1]="(A) Graeme Smith";
				q[2]="(B) Ricky Ponting";
				q[3]="(C) Steve Waugh";
				q[4]="(D) Arjuna Ranatunga";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="What was the name of Vijay Deenanath Chauhan’s village in the film ‘Agneepath’?";
				q[1]="(A) Charanpur";
				q[2]="(B) Mandava";
				q[3]="(C) Champaner";
				q[4]="(D) RamGadh";
				q[5]="B";
				break;
			}
			case 8:
			{
				q[0]="Which police officer’s biography is titled ‘I Dare!’?";
				q[1]="(A) Kiran Bedi";
				q[2]="(B) J. F. Ribeiro";
				q[3]="(C) Hemant Karkare";
				q[4]="(D) K. P. S. Gill";
				q[5]="A";
				break;
			}
			case 9:
			{
				q[0]="In which of these areas in India would you find the ‘kiang’ the largest variety of Asiatic wild ass?";
				q[1]="(A) Kutch";
				q[2]="(B) Bundelkhand";
				q[3]="(C) Ladakh";
				q[4]="(D) Dooars";
				q[5]="C";
				break;
			}
			case 10:
			{
				q[0]="Which of these proverbs would you use to describe someone getting married?";
				q[1]="(A) Haath Baandhna";
				q[2]="(B) Haath Phailana";
				q[3]="(C) Haath Peeley Karna";
				q[4]="(D) Haath Laal Karna";
				q[5]="C";
				break;
			}
		}
		return q;
	}
}