package Questions;
public class FiftyLakh
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="In which of these sectors was 51% FDI permitted by the Government of India in 2012?";
				q[1]="(A) Multi-brand retail";
				q[2]="(B) Healthcare";
				q[3]="(C) Life Insurance";
				q[4]="(D) Civil Aviation";
				q[5]="A";
				break;
			}
			case 2:
			{
				q[0]="The first woman president of India, Pratibha Patil, was the first woman governor of which state ?";
				q[1]="(A) Maharashtra";
				q[2]="(B) Rajasthan";
				q[3]="(C) Gujarat";
				q[4]="(D) Goa";
				q[5]="B";
				break;
			}
			case 3:
			{
				q[0]="Arrange these ports in the order in which you will come across them, while traveling from Gujarat to Odisha by sea route.(1) Visakhapatnam (2) Kandla (3) Paradip (4) Mangalore";
				q[1]="(A)1-4-3-2";
				q[2]="(B)2-1-4-3";
				q[3]="(C)2-4-1-3";
				q[4]="(D)3-2-4-1";
				q[5]="C";
				break;
			}
			case 4:
			{
				q[0]="Which of these feats was achieved by Virender Sehwag in November 2012 ?";
				q[1]="(A) Took a hat-trick in tests";
				q[2]="(B) Played his 100th Test";
				q[3]="(C) Hit a triple century in a Test";
				q[4]="(D) Hit Six sixes in an over";
				q[5]="B";
				break;
			}
			case 5:
			{
				q[0]="Who among these became a Union Minister before his or her father became one ?";
				q[1]="(A) Omar Abdullah";
				q[2]="(B) Naveen Patnaik";
				q[3]="(C) Agatha Sangma";
				q[4]="(D) Sachin Pilot";
				q[5]="A";
				break;
			}
			case 6:
			{
				q[0]="The Nepanagar town of Madhya Pradesh is a prominent manufacturing center of which of these products?";
				q[1]="(A) Fertilizers";
				q[2]="(B) Newsprint Paper";
				q[3]="(C) Petroleum";
				q[4]="(D) Cement";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="In which city are the tomb of Ibrahim Lodi and the samadhi of king Hemu located?";
				q[1]="(A) Delhi";
				q[2]="(B) Agra";
				q[3]="(C) Paniput";
				q[4]="(D) Ambala";
				q[5]="C";
				break;
			}
			case 8:
			{
				q[0]="Which of these Indian currency notes does not have the special geometrical shape that helps the visually impaired denominations?";
				q[1]="(A) Rs 100";
				q[2]="(B) Rs 50";
				q[3]="(C) Rs 1000";
				q[4]="(D) Rs 10";
				q[5]="D";
				break;
			}
			case 9:
			{
				q[0]="Which of these vice president of India was earlier chief minister of his state?";
				q[1]="(A) Zakir Hussain";
				q[2]="(B) V. V. Giri";
				q[3]="(C) Bhairon Singh Shekhawat";
				q[4]="(D) R. Venkalaraman";
				q[5]="C";
				break;
			}
			case 10:
			{
				q[0]="Who wrote the poem ‘Hum Panchi Unmukt Gagan Ke’?";
				q[1]="(A) Shivmangal Singh ‘Suman’";
				q[2]="(B) Ayodhya Singh Upadhyay ‘Hariaudh’";
				q[3]="(C) Suryakanth Tripathi ‘Nirala’";
				q[4]="(D) Jayshankar Prasad";
				q[5]="A";
				break;
			}
		}
		return q;
	}
}