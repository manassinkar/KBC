package Questions;
public class EightyThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Who is the first woman to successfully climb K2, the world’s second highest mountain peak ?";
				q[1]="(A) Junko Tabei";
				q[2]="(B) Wanda Rutklewicz";
				q[3]="(C) Tamae Watanabe";
				q[4]="(D) Chantal Mauduit";
				q[5]="B";
				break;
			}
			case 2:
			{
				q[0]="Which god is also known as “Dasrath Nandan’?";
				q[1]="(A) Ram";
				q[2]="(B) Agni";
				q[3]="(C) Ganesh";
				q[4]="(D) Karthikeyan";
				q[5]="A";
				break;
			}
			case 3:
			{
				q[0]="Which of these terms in not named after a Nobel Laureate?";
				q[1]="(A) Raman Effect";
				q[2]="(B) Chandrasekhar Limit";
				q[3]="(C) Ramanujan number";
				q[4]="(D) Sen Index";
				q[5]="C";
				break;
			}
			case 4:
			{
				q[0]="Which of these folk songs derives its name from the name of Hindi month?";
				q[1]="(A) Kajari";
				q[2]="(B) Chaiti";
				q[3]="(C) Sohar";
				q[4]="(D) Hori";
				q[5]="B";
				break;
			}
			case 5:
			{
				q[0]="Arrange these mountains peaks in decreasing order of their height above sea level(1) Kanchenjunga (2) K2 (3) Mount Everest (4) Nanda Devi";
				q[1]="(A)3-2-4-1";
				q[2]="(B)2-3-1-4";
				q[3]="(C)3-2-1-4";
				q[4]="(D)1-4-3-2";
				q[5]="A";
				break;
			}
			case 6:
			{
				q[0]="Which among these is an Island country ?";
				q[1]="(A) Yemen";
				q[2]="(B) Maldives";
				q[3]="(C) Oman";
				q[4]="(D) Peru";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="What has been the currency of Greece since 2002?";
				q[1]="(A) Euro";
				q[2]="(B) peso";
				q[3]="(C) Drachma";
				q[4]="(D) Lira";
				q[5]="A";
				break;
			}
			case 8:
			{
				q[0]="Which incarnation of Vishnu appeared when the demon king Bali ruled the entire universe ?";
				q[1]="(A) Rama";
				q[2]="(B) Varaha";
				q[3]="(C) Vamana";
				q[4]="(D) Parashurama";
				q[5]="C";
				break;
			}
			case 9:
			{
				q[0]="In 1610, who first observed the planet Saturn through a telescope?";
				q[1]="(A) Galileo Galilei";
				q[2]="(B) Nicolaus Copernicus";
				q[3]="(C) Giovanni Cassini";
				q[4]="(D) Giordano Bruno";
				q[5]="A";
				break;
			}
			case 10:
			{
				q[0]="Which of these tourist attractions is situated on an island ?";
				q[1]="(A) Ellora Caves";
				q[2]="(B) Ajanta Caves";
				q[3]="(C) Kanheri Caves";
				q[4]="(D) Elephanta Caves";
				q[5]="D";
				break;
			}
		}
		return q;
	}
}