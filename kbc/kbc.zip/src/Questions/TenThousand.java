package Questions;
public class TenThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Floor exercise, vault, and uneven bars are events in which sport ?";
				q[1]="(A) Synchronised Swimming";
				q[2]="(B) Gymnastics";
				q[3]="(C) Skating";
				q[4]="(D) Wrestling";
				q[5]="B";
				break;
			}
			case 2:
			{
				q[0]="According to a proverb, what is said to be ‘the mother of invention’ ?";
				q[1]="(A) Society";
				q[2]="(B) Problem";
				q[3]="(C) Science";
				q[4]="(D) Necessity";
				q[5]="D";
				break;
			}
			case 3:
			{
				q[0]="In the Film 'OMG Oh My God' Kanji Bhai filed a case against whom for the damage of his shop due to an earthquake ?";
				q[1]="(A) Bharat Mata";
				q[2]="(B) Parliament (Bhartiya Sansad)";
				q[3]="(C) Mumbai City";
				q[4]="(D) Bhagwan (God)";
				q[5]="D";
				break;
			}
			case 4:
			{
				q[0]="What is the new name of the Hyderabad franchise that would replace Deccan Charges in IPL6?";
				q[1]="(A) Sun Chargers";
				q[2]="(B) Nizam Jyothi";
				q[3]="(C) Andhra Aces";
				q[4]="(D) Sun risers Hyderabad";
				q[5]="D";
				break;
			}
			case 5:
			{
				q[0]="Starting from the earliest , arrange these events associated with Pakistan in chronological order(1) Benazir Bhutto became PM (2) Formation of Pakistan (3) Kargil War (4) Formation of Bangladesh";
				q[1]="(A)3-1-4-2";
				q[2]="(B)1-2-4-3";
				q[3]="(C)2-1-4-3";
				q[4]="(D)2-4-1-3";
				q[5]="D";
				break;
			}
			case 6:
			{
				q[0]="Which of these is a part of the name of a tiger reserve situated in Bihar?";
				q[1]="(A) Janaki";
				q[2]="(B) Mahavira";
				q[3]="(C) Valmiki";
				q[4]="(D) Ashoka";
				q[5]="C";
				break;
			}
			case 7:
			{
				q[0]="Sachin Tendulkar plays his last one day international match against which country?";
				q[1]="(A) Australia";
				q[2]="(B) Sri Lanka";
				q[3]="(C) Pakistan";
				q[4]="(D) England";
				q[5]="C";
				break;
			}
			case 8:
			{
				q[0]="In the Mahabharata, what art did Eklavya teach himself by practising in front of a status of Dronacharya, who he considered his Guru?";
				q[1]="(A) Mace Fighting";
				q[2]="(B) Spear Throw";
				q[3]="(C) Sword Fighting";
				q[4]="(D) Archery";
				q[5]="D";
				break;
			}
			case 9:
			{
				q[0]="Which of these proverbs means 'to get very frightened'?";
				q[1]="(A) Dimaag Phirna";
				q[2]="(B) Jee Jalna";
				q[3]="(C) Roo Kampna";
				q[4]="(D) Aankhen Churana";
				q[5]="C";
				break;
			}
			case 10:
			{
				q[0]="Most of the world’s population of the greater one-horned rhinoceros inhabits which national park in India?";
				q[1]="(A) Manas National Park";
				q[2]="(B) Kaziranga National Park";
				q[3]="(C) Kanha National Park";
				q[4]="(D) Gorumara National Park";
				q[5]="B";
				break;
			}
		}
		return q;
	}
}