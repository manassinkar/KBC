package Questions;
public class ThreeLakhTwentyThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="In which edition of the Olympics did women participate for the first time?";
				q[1]="(A) Paris, 1900";
				q[2]="(B) London, 1908";
				q[3]="(C) Antwerp, 1920";
				q[4]="(D) Berlin, 1916";
				q[5]="A";
				break;
			}
			case 2:
			{
				q[0]="In 2011, who replaced Gary Kirsten as the coach of the Indian Test cricket team?";
				q[1]="(A) Dav Whatmore";
				q[2]="(B) John Wright";
				q[3]="(C) Duncan Fletcher";
				q[4]="(D) Gerg Chappel";
				q[5]="C";
				break;
			}
			case 3:
			{
				q[0]="Arrange the following festivals in the order in which they were held or will be held in the year 2012.(1) Janmashtami (2) Rakshabandhan (3) Dussehra (4) Diwali";
				q[1]="(A)1-3-4-2";
				q[2]="(B)2-1-3-4";
				q[3]="(C)1-2-3-4";
				q[4]="(D)2-3-1-4";
				q[5]="B";
				break;
			}
			case 4:
			{
				q[0]="What is the meaning of the Persian word ‘Ab’ used in the word ‘Punjab’ ?";
				q[1]="(A) Tree";
				q[2]="(B) Water";
				q[3]="(C) Mountain";
				q[4]="(D) Grain";
				q[5]="B";
				break;
			}
			case 5:
			{
				q[0]="What was the name of Jain tirtankar Mahavira’s wife?";
				q[1]="(A) Devaki";
				q[2]="(B) Rohini";
				q[3]="(C) Subhadra";
				q[4]="(D) Yashoda";
				q[5]="D";
				break;
			}
			case 6:
			{
				q[0]="Which state or UT of India is divided into four districts – all named after the four cardinal directories?";
				q[1]="(A) Sikkim";
				q[2]="(B) Goa";
				q[3]="(C) Manipur";
				q[4]="(D) Chandigarh";
				q[5]="A";
				break;
			}
			case 7:
			{
				q[0]="Who amount these was the first lady Air Marshal of the Indian Air Force?";
				q[1]="(A) Lakshmi Sehgal";
				q[2]="(B) Padmavathy Bandopadhyay";
				q[3]="(C) Nirmala Kannan";
				q[4]="(D) Puneeta Arora";
				q[5]="B";
				break;
			}
			case 8:
			{
				q[0]="What was the first ministerial portfolio held by Indira Gandhi?";
				q[1]="(A) Home Affairs";
				q[2]="(B) Information & Broadcasting";
				q[3]="(C) Science & Technology";
				q[4]="(D) Education";
				q[5]="B";
				break;
			}
			case 9:
			{
				q[0]="Which of these world champions is a parent of twins?";
				q[1]="(A) Sushil Kumar";
				q[2]="(B) M. C. Mary Kom";
				q[3]="(C) Vishwanathan Anand";
				q[4]="(D) Gagan Narang";
				q[5]="B";
				break;
			}
			case 10:
			{
				q[0]="Bharatpur Bird Century was named Keoladeo Ghana National Park after a temple dedicated to which God or Goddess?";
				q[1]="(A) Kali";
				q[2]="(B) Yama";
				q[3]="(C) Kuber";
				q[4]="(D) Shiva";
				q[5]="D";
				break;
			}
		}
		return q;
	}
}