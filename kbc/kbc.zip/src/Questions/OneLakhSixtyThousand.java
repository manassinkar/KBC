package Questions;
public class OneLakhSixtyThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="On which of these routes does India’s fastest passenger train run ?";
				q[1]="(A) New Delhi – Bhopal";
				q[2]="(B) New Delhi – Jaipur";
				q[3]="(C) Mumbai – Pune";
				q[4]="(D) New Delhi – Lucknow";
				q[5]="A";
				break;
			}
			case 2:
			{
				q[0]="Which of these is the name of a drink consumed by Hindu Gods?";
				q[1]="(A) Amrit Boond";
				q[2]="(B) Madhu Pan";
				q[3]="(C) Ksheer Sagar";
				q[4]="(D) Som ras";
				q[5]="D";
				break;
			}
			case 3:
			{
				q[0]="Which director won the Filmfare Award for ‘Best Director’ most number of times ?";
				q[1]="(A) Yash Chopra";
				q[2]="(B) Bimal Roy";
				q[3]="(C) Raj Kapoor";
				q[4]="(D) B. R. Chopra";
				q[5]="B";
				break;
			}
			case 4:
			{
				q[0]="According to the Bhagavat Purana, who among the following once changed the course of the river Yamuna with a plough?";
				q[1]="(A) Krishna";
				q[2]="(B) Kamsa";
				q[3]="(C) Balarama";
				q[4]="(D) Bhima";
				q[5]="C";
				break;
			}
			case 5:
			{
				q[0]="Who is the only Indian to have won a gold medal in the 100m sprint at the Asian Games?";
				q[1]="(A) Ajmer Singh";
				q[2]="(B) M. Gabriel";
				q[3]="(C) Kennath Powell";
				q[4]="(D) Lavy Pinto";
				q[5]="D";
				break;
			}
			case 6:
			{
				q[0]="Which of these constituencies has been represented in the Lok Sabha by a father and daughter both?";
				q[1]="(A) Amethi";
				q[2]="(B) Sasaram";
				q[3]="(C) New Delhi";
				q[4]="(D) Gwalior";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="Which of these national parks, reserved for tigers, is named after a river?Which of these national parks, reserved for tigers, is named after a river?";
				q[1]="(A) Dudhwa";
				q[2]="(B) Sunderbans";
				q[3]="(C) Indrawati";
				q[4]="(D) Kanha";
				q[5]="C";
				break;
			}
			case 8:
			{
				q[0]="At which of these places did Chanakya get Chandragupta Maurya trained in the art of war and politics?";
				q[1]="(A) Takshashila";
				q[2]="(B) Kashi";
				q[3]="(C) Ujjain";
				q[4]="(D) Naianda";
				q[5]="A";
				break;
			}
			case 9:
			{
				q[0]="Which of these sports events is named after a place?";
				q[1]="(A) Tennis";
				q[2]="(B) Soccer";
				q[3]="(C) Marathon";
				q[4]="(D) Squash";
				q[5]="C";
				break;
			}
			case 10:
			{
				q[0]="In 1846, what was bought by Gulab Singh from the British for Rs 75 lakhs?";
				q[1]="(A) Simla";
				q[2]="(B) Kumaon";
				q[3]="(C) Kashmir";
				q[4]="(D) Garhwal";
				q[5]="C";
				break;
			}
		}
		return q;
	}
}