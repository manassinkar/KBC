package Questions;
public class SixLakhFortyThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="In the context of space exploration, what does the P in PSLV stand for?";
				q[1]="(A) Planet";
				q[2]="(B) Polar";
				q[3]="(C) Power";
				q[4]="(D) Point";
				q[5]="B";
				break;
			}
			case 2:
			{
				q[0]="In India, under which Union Ministry does the ‘Rajbhasha Vibhag’ function?";
				q[1]="(A) Home Affairs";
				q[2]="(B) HRD";
				q[3]="(C) Culture";
				q[4]="(D) Law & Justice";
				q[5]="A";
				break;
			}
			case 3:
			{
				q[0]="Which constituency does Abhijit Mukherjee represents in the 15th Lok Sabha ?";
				q[1]="(A) Jadavpur";
				q[2]="(B) Birbhum";
				q[3]="(C) Jangipur";
				q[4]="(D) Midnapore";
				q[5]="C";
				break;
			}
			case 4:
			{
				q[0]="Which of these ships was not part of Christopher Columbus’s first voyage in 1492 ?";
				q[1]="(A) Nina";
				q[2]="(B) La Gorda";
				q[3]="(C) Pinta";
				q[4]="(D) Santa Maria";
				q[5]="B";
				break;
			}
			case 5:
			{
				q[0]="With which religion would you associate the practice of Santhara fasting unto death?";
				q[1]="(A) Jainism";
				q[2]="(B) Sikhism";
				q[3]="(C) Shintoism";
				q[4]="(D) Buddhism";
				q[5]="A";
				break;
			}
			case 6:
			{
				q[0]="Which of these actress is married to a professional golfer?";
				q[1]="(A) Chitrangada Singh";
				q[2]="(B) Celina Jaitly";
				q[3]="(C) Esha Deol";
				q[4]="(D) Ayesha Takia";
				q[5]="A";
				break;
			}
			case 7:
			{
				q[0]="Which of these is not a work of Kalidas?";
				q[1]="(A) Raghuvamsham";
				q[2]="(B) Meghadutam";
				q[3]="(C) Vikramorvasiyam";
				q[4]="(D) Kadambari";
				q[5]="D";
				break;
			}
			case 8:
			{
				q[0]="Whose different forms are 'Shailputri', 'Brahmcharani' and 'Chandraghanta' ?";
				q[1]="(A) Rati";
				q[2]="(B) Ganga";
				q[3]="(C) Durga";
				q[4]="(D) Menaka";
				q[5]="C";
				break;
			}
			case 9:
			{
				q[0]="Which of these is the name of an island as well as a type of coffee?";
				q[1]="(A) Mocha";
				q[2]="(B) Arabica";
				q[3]="(C) Java";
				q[4]="(D) Oolong";
				q[5]="C";
				break;
			}
			case 10:
			{
				q[0]="If you are driving 'Chappu' , Then It mean that you are traveling with....?";
				q[1]="(A) bail Gadi (Bullock Cart)";
				q[2]="(B) Tanga (carriage)";
				q[3]="(C) Doli";
				q[4]="(D) Naav (Boat)";
				q[5]="D";
				break;
			}
		}
		return q;
	}
}