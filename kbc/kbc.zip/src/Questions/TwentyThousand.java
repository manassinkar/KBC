package Questions;
public class TwentyThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Starting from the northernmost , arrange these capital cities in clockwise direction.(1) Mumbai (2) Kolkatta (3) Delhi (4) Chennai";
				q[1]="(A)1-3-4-2";
				q[2]="(B)4-2-3-1";
				q[3]="(C)3-2-4-1";
				q[4]="(D)3-4-2-1";
				q[5]="C";
				break;
			}
			case 2:
			{
				q[0]="Which of these is a kind of dance as well as an ornament worn on the head ?";
				q[1]="(A) Ghoomar";
				q[2]="(B) Giddha";
				q[3]="(C) Jhoomar";
				q[4]="(D) Bhangra";
				q[5]="C";
				break;
			}
			case 3:
			{
				q[0]="Which of these names means ‘lightning’?";
				q[1]="(A) Saumaya";
				q[2]="(B) Damani";
				q[3]="(C) Shreya";
				q[4]="(D) Mahima";
				q[5]="B";
				break;
			}
			case 4:
			{
				q[0]="Which part of 'Pudina' plant is normally used to make 'pudina chutney' ?";
				q[1]="(A) Seed";
				q[2]="(B) Flower";
				q[3]="(C) Root";
				q[4]="(D) Leaves";
				q[5]="D";
				break;
			}
			case 5:
			{
				q[0]="The sanskrit word 'Himalaya' means 'The place of ____'?";
				q[1]="(A) Devata";
				q[2]="(B) Barf";
				q[3]="(C) Hindu";
				q[4]="(D) Tapasaya";
				q[5]="B";
				break;
			}
			case 6:
			{
				q[0]="According to the Devi, Bhagavata, from the tears of which god is the rudraksha tree believed to have been created?";
				q[1]="(A) Vishnu";
				q[2]="(B) Shiva";
				q[3]="(C) Nhrama";
				q[4]="(D) Kamadeva";
				q[5]="B";
				break;
			}
			case 7:
			{
				q[0]="Lockjaw is a symptom of which of these disease?";
				q[1]="(A) Tetanus";
				q[2]="(B) Cholera";
				q[3]="(C) Plague";
				q[4]="(D) Diphtheria";
				q[5]="A";
				break;
			}
			case 8:
			{
				q[0]="Which of the following mean head of Police Station 'Thanedaar ' ?";
				q[1]="(A) Kirani";
				q[2]="(B) Hawaldar";
				q[3]="(C) Daroga";
				q[4]="(D) Munshi";
				q[5]="C";
				break;
			}
			case 9:
			{
				q[0]="Which Indian sportsperson was awarded the 'order of Australia' award in 2012?";
				q[1]="(A) Saina Nehwal";
				q[2]="(B) Sachin Tendulkar";
				q[3]="(C) Sania Mirza";
				q[4]="(D) Rahul Dravid";
				q[5]="B";
				break;
			}
			case 10:
			{
				q[0]="Which actress got married to Siddharth Roy Kapoor in 2012 ?";
				q[1]="(A) Prachi Desai";
				q[2]="(B) Lisa Ray";
				q[3]="(C) Vidya Balan";
				q[4]="(D) Sushmita Sen";
				q[5]="C";
				break;
			}
		}
		return q;
	}
}