package Questions;
public class OneCrore
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Kanchenjunga is widely regarded as the guardian deity of which state ?";
				q[1]="(A) Assam";
				q[2]="(B) Arunachal Pradesh";
				q[3]="(C) West Bengal";
				q[4]="(D) Sikkim";
				q[5]="D";
				break;
			}
			case 2:
			{
				q[0]="Who is the only woman author to get the Jnanpith Award for Hindi literature ?";
				q[1]="(A) Shivani";
				q[2]="(B) Subhadra Kumari Chauchan";
				q[3]="(C) Mahadevi Verma";
				q[4]="(D) Krishna Sobti";
				q[5]="C";
				break;
			}
			case 3:
			{
				q[0]="Where was Mughal empress Mumtaz Mahal originally buried in 1631 ?";
				q[1]="(A) Agra";
				q[2]="(B) Burhanpur";
				q[3]="(C) Gwalior";
				q[4]="(D) Lahore";
				q[5]="B";
				break;
			}
			case 4:
			{
				q[0]="Which group did Sampat Pal Devi found in 2006 to protect women from domestic violence and abuse?";
				q[1]="(A) Nari Mukti Vahini";
				q[2]="(B) Mahila Morcha";
				q[3]="(C) Bundelkhand Gang";
				q[4]="(D) Gulabi Gang";
				q[5]="D";
				break;
			}
			case 5:
			{
				q[0]="In the early phase of his career, which of these industrialists used to sell handmade detergent packets from door to door?";
				q[1]="(A) Karsanbhai Patel";
				q[2]="(B) Azim Premji";
				q[3]="(C) Gujarmal Modi";
				q[4]="(D) Brijmohan Lail Munjal";
				q[5]="A";
				break;
			}
			case 6:
			{
				q[0]="Who defended Bal Ganghadhar Tilak in court in 1908 and in 1915 when he was charged with sedition by the British Government?";
				q[1]="(A) Motilal Nehru";
				q[2]="(B) Chittaranjan Das";
				q[3]="(C) Sir Pherozeshah Mehta";
				q[4]="(D) Muhammad Ali Jinnah";
				q[5]="D";
				break;
			}
			case 7:
			{
				q[0]="According to Hindu mythology, who incarnated as Rama in the Treta Yuga and as Krishna in the Dwapara Yuga?";
				q[1]="(A) Shiva";
				q[2]="(B) Ganesha";
				q[3]="(C) Brahma";
				q[4]="(D) Vishnu";
				q[5]="D";
				break;
			}
			case 8:
			{
				q[0]="Who is the director of the film ‘Mitr’, My Friend which had primarily an all female filming crew?";
				q[1]="(A) Aparna Sen";
				q[2]="(B) Revathi";
				q[3]="(C) Sai Paranjpe";
				q[4]="(D) Deepa Mehta";
				q[5]="B";
				break;
			}
			case 9:
			{
				q[0]="Which of the following are Cirrus, Stratus and Cumulus all types of?";
				q[1]="(A) Clouds";
				q[2]="(B) Ocean Currents";
				q[3]="(C) Winds";
				q[4]="(D) Hurricanes";
				q[5]="A";
				break;
			}
			case 10:
			{
				q[0]="Which was the First Company to issue Bonds and Shares of Stock to the general public?";
				q[1]="(A) Royal Bank of Scotland";
				q[2]="(B) Dutch East India Company";
				q[3]="(C) Colgate";
				q[4]="(D) Procter & Gamble";
				q[5]="B";
				break;
			}
		}
		return q;
	}
}