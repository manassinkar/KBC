package Questions;
public class TwoThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Starting from the earliest, arrange these actress in the order in which their first film was released?(1) Sonakshi Sinha (2) Juhi Chawla (3) Saira Banu (4) Kajol";
				q[1]="(A) 3-2-4-1";
				q[2]="(B) 2-3-1-4";
				q[3]="(C) 3-1-2-4";
				q[4]="(D) 4-1-3-2";
				q[5]="A";
				break;
			}
			case 2:
			{
				q[0]="The largest organ of the body is–";
				q[1]="(A) Large Intestine";
				q[2]="(B) Skin";
				q[3]="(C) Liver";
				q[4]="(D) Stomach";
				q[5]="B";
				break;
			}
			case 3:
			{
				q[0]="Which of these politicians has been the Presidents of the Indian National Congress for the longest period?";
				q[1]="(A) Jawaharlal Nehru";
				q[2]="(B) Indira Gandhi";
				q[3]="(C) Rajiv Gandhi";
				q[4]="(D) Sonia Gandhi";
				q[5]="D";
				break;
			}
			case 4:
			{
				q[0]="In which of these games does a player need to enter the opponent’s court to get them out?";
				q[1]="(A) Kho-Kho";
				q[2]="(B) Kabaddi";
				q[3]="(C) Boxing";
				q[4]="(D) Judo";
				q[5]="B";
				break;
			}
			case 5:
			{
				q[0]="Which of these geometrical shapes has the least number of sides?";
				q[1]="(A) Cube";
				q[2]="(B) Pentagon";
				q[3]="(C) Square";
				q[4]="(D) Triangle";
				q[5]="D";
				break;
			}
			case 6:
			{
				q[0]="What do the five rings of the Olympics represent?";
				q[1]="(A) Five games";
				q[2]="(B) Five languages";
				q[3]="(C) Five continents";
				q[4]="(D) Five oceans";
				q[5]="C";
				break;
			}
			case 7:
			{
				q[0]="Which of these words can refer to ‘a fairly low temperature’ or ‘fashionably’ or impressive?";
				q[1]="(A) Met";
				q[2]="(B) Wow";
				q[3]="(C) Chic";
				q[4]="(D) Cool";
				q[5]="D";
				break;
			}
			case 8:
			{
				q[0]="Emulsion, primer and undercoat are all terms connected with what ?";
				q[1]="(A) Painting";
				q[2]="(B) Knitting";
				q[3]="(C) Sewing";
				q[4]="(D) Cooking";
				q[5]="A";
				break;
			}
			case 9:
			{
				q[0]="What does the ‘F’ stands for in the Motorsports popularly known as F1?";
				q[1]="(A) Fast";
				q[2]="(B) Force";
				q[3]="(C) Formula";
				q[4]="(D) Fly";
				q[5]="C";
				break;
			}
			case 10:
			{
				q[0]="During his tenure as Chief minister, who once said that he dreamt of turning Mumbai into a Shanghai ?";
				q[1]="(A) Vilasrao Deshmukh";
				q[2]="(B) Ashok Chavan";
				q[3]="(C) Sushil Kumar Shinde";
				q[4]="(D) Sharad Pawar";
				q[5]="A";
				break;
			}
		}
		return q;
	}
}