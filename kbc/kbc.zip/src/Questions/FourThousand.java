package Questions;
public class FourThousand
{
	String q[]=new String[6];
	public String[] ques(int random)
	{
		switch(random)
		{
			case 1:
			{
				q[0]="Javitri, used as a spice, is the fragrant part of the kernel of what ?";
				q[1]="(A) Saffron";
				q[2]="(B) Cumin";
				q[3]="(C) Black pepper";
				q[4]="(D) Nutmeg";
				q[5]="D";
				break;
			}
			case 2:
			{
				q[0]="What part of the body is normally cut open during an appendix operation?";
				q[1]="(A) Abdomen";
				q[2]="(B) Chest";
				q[3]="(C) Head";
				q[4]="(D) Neck";
				q[5]="A";
				break;
			}
			case 3:
			{
				q[0]="Which of the following name means “Person of long age “?";
				q[1]="(A) Abhitabh";
				q[2]="(B) Arunodaya";
				q[3]="(C) Abhishek";
				q[4]="(D) Ayushmaan";
				q[5]="D";
				break;
			}
			case 4:
			{
				q[0]="According to a TV ad, Which duo goes to the tailor and says , 'Masterji, pitaji ki patloon ek bilang chhoti kar do' ?";
				q[1]="(A) Hari – Harish";
				q[2]="(B) Santa – Banta";
				q[3]="(C) Ramesh – Suresh";
				q[4]="(D) Ajay – Vijay";
				q[5]="C";
				break;
			}
			case 5:
			{
				q[0]="Which of these organs helps in maintaining the sense of balance or equilibrium of our body?";
				q[1]="(A) Nose";
				q[2]="(B) Ears";
				q[3]="(C) Tongue";
				q[4]="(D) Lungs";
				q[5]="B";
				break;
			}
			case 6:
			{
				q[0]="Which of these proverbs means the same as ‘Hosh Udna’ or ‘Hosh thikane lagna’?";
				q[1]="(A) Biwi pe pyar aana";
				q[2]="(B) Daant Dikhana";
				q[3]="(C) Naani Yaad aana";
				q[4]="(D) L Hay Tauba Machana";
				q[5]="C";
				break;
			}
			case 7:
			{
				q[0]="People from which of these professions are most likely to use ‘aari’, ‘basula’ and ‘burma’ at their work?";
				q[1]="(A) Tailor";
				q[2]="(B) Carpenter";
				q[3]="(C) Washerman";
				q[4]="(D) Painter";
				q[5]="B";
				break;
			}
			case 8:
			{
				q[0]="Which of the following animals do not have external ears?";
				q[1]="(A) Cat";
				q[2]="(B) Snake";
				q[3]="(C) Rat";
				q[4]="(D) Bat";
				q[5]="B";
				break;
			}
			case 9:
			{
				q[0]="Who was the Chairman of the Drafting committee of the Constituent of India?";
				q[1]="(A) Rajendra Prasad";
				q[2]="(B) B. R. Ambedkar";
				q[3]="(C) Vallabhbhai Patel";
				q[4]="(D) G. V. Mavalankar";
				q[5]="B";
				break;
			}
			case 10:
			{
				q[0]="Which of these Indian cricketers made his Test Debut in 2012?";
				q[1]="(A) Abhinav Mukund";
				q[2]="(B) Ajinkya Rahane";
				q[3]="(C) Ravindra Jadeja";
				q[4]="(D) Rohit Sharma";
				q[5]="C";
				break;
			}
		}
		return q;
	}
}